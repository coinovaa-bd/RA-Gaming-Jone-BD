# RA Gaming Jone — 10 Playable 3D Arcade Games

This project contains ten playable Three.js/WebGL arcade mini-games, a gold/black app identity, a local demo owner panel, and Capacitor Android packaging with Google AdMob test placements.

## Games and controls
- Battle Royale: move left/right and fire at approaching opponents.
- Car Racing: change lanes and jump to avoid traffic; survive for the timer.
- Zombie Survival: move and shoot approaching zombies.
- Football Challenge: move to aim, then kick; beat the moving goalkeeper.
- Sniper Mission: aim horizontally and fire at each moving target.
- Bike Racing: switch lanes and jump over traffic.
- Shadow Fight: move close, punch, and use block to defend.
- Bubble Shooter: fire bubbles upward to pop matching targets.
- Endless Run: change lanes and jump over traffic.
- Car Parking: steer into the highlighted bay; ACTION advances the car.

All games are lightweight arcade experiences using simple 3D geometry and arcade-style collision/score rules. They are not AAA commercial games and do not include online multiplayer.

## Run locally
1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Run `npm run dev` to preview in a browser.
4. Run `npm run build` to produce the web build.

## Android APK with GitHub Actions
1. Upload the whole repository to GitHub.
2. Open Actions and run **Build Android APK**.
3. Download the generated APK artifact after the workflow completes.

## AdMob
The included AdMob unit IDs are Google's official test IDs and `ADMOB_TEST_MODE` is `true`. This is intentional for safe development. Before release, create/configure your own AdMob app and ad units, follow Google's consent/privacy requirements, replace the test IDs in `src/admob-config.js`, set test mode to `false`, and rebuild. Live ads and earnings are subject to AdMob approval and policy compliance; revenue is not guaranteed. Never click your own ads or use fake/incentivized clicks.

## Admin demo
The local demo PIN is `2580`. It is not secure authentication. Do not use this as a production admin security system.
