import fs from 'node:fs';
const manifest = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(manifest)) throw new Error(`Android manifest not found: ${manifest}`);
const appId = process.env.ADMOB_APP_ID || 'ca-app-pub-3940256099942544~3347511713'; // Google's sample app ID for test builds
let xml = fs.readFileSync(manifest, 'utf8');
const meta = `<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="${appId}" />`;
if (xml.includes('com.google.android.gms.ads.APPLICATION_ID')) {
  xml = xml.replace(/<meta-data[^>]*com\.google\.android\.gms\.ads\.APPLICATION_ID[^>]*\/>/, meta);
} else {
  xml = xml.replace(/<application([^>]*)>/, `<application$1>\n        ${meta}`);
}
fs.writeFileSync(manifest, xml);
console.log('Configured Google Mobile Ads application ID (test ID unless ADMOB_APP_ID secret is set).');
