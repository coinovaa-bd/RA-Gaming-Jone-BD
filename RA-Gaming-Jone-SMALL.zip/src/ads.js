import { Capacitor } from '@capacitor/core';
import { ADMOB_IDS, ADMOB_TEST_MODE } from './admob-config.js';

let AdMobPlugin;
let initialized = false;

export async function initializeAds() {
  if (!Capacitor.isNativePlatform() || initialized) return false;
  try {
    const plugin = await import('@capacitor-community/admob');
    AdMobPlugin = plugin;
    await plugin.AdMob.initialize();
    await plugin.AdMob.showBanner({
      adId: ADMOB_IDS.banner,
      adSize: plugin.BannerAdSize.ADAPTIVE_BANNER,
      position: plugin.BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: ADMOB_TEST_MODE
    });
    initialized = true;
    return true;
  } catch (error) {
    console.warn('AdMob is not ready. Check app ID, ad unit IDs and consent setup.', error);
    return false;
  }
}

// A user-initiated rewarded ad. This does not promise cash or pay users.
export async function showRewardedAd() {
  if (!Capacitor.isNativePlatform()) {
    alert('Real AdMob ads are available in the installed Android app, not the browser preview.');
    return false;
  }
  try {
    if (!AdMobPlugin) {
      const plugin = await import('@capacitor-community/admob');
      AdMobPlugin = plugin;
      await plugin.AdMob.initialize();
    }
    await AdMobPlugin.AdMob.prepareRewardVideoAd({
      adId: ADMOB_IDS.rewarded,
      isTesting: ADMOB_TEST_MODE
    });
    const reward = await AdMobPlugin.AdMob.showRewardVideoAd({ adId: ADMOB_IDS.rewarded });
    return Boolean(reward);
  } catch (error) {
    console.warn('Rewarded ad was not shown.', error);
    alert('Ad এখন পাওয়া যাচ্ছে না। পরে আবার চেষ্টা করো।');
    return false;
  }
}
