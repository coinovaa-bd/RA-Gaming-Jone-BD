// Google demo ad units are safe for development. Replace these with your own AdMob ad unit IDs after approval.
export const ADMOB_TEST_MODE = true;
export const ADMOB_IDS = {
  banner: 'ca-app-pub-3940256099942544/6300978111',
  interstitial: 'ca-app-pub-3940256099942544/1033173712',
  rewarded: 'ca-app-pub-3940256099942544/5224354917'
};
